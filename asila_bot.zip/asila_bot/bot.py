import os
import random
import sqlite3
import logging

from dotenv import load_dotenv
from google import genai
from google.genai import types
from telegram import Update
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler,
    filters, ContextTypes,
)

load_dotenv()

TG_TOKEN = os.environ["TG_TOKEN"]
ASILA_ID = int(os.environ["ASILA_ID"])
BOT_NAME = os.getenv("BOT_NAME", "Do'stcha")
MODEL = os.getenv("MODEL", "gemini-2.5-flash")
DB_PATH = os.getenv("DB_PATH", "data.db")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("bot")

client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
only_asila = filters.User(user_id=ASILA_ID)

PERSONA = f"""Sen {BOT_NAME}san, Asilaning yaqin do'sti va suhbatdoshisan.
Faqat Asila bilan gaplashasan. Uni yaxshi ko'rasan, qadrlaysan, u bilan har narsa haqida gaplasha olasan.
Uslub: iliq, samimi, hazilkash, "sen" deb murojaat qil, o'zbek tilida (u boshqa tilda yozsa, o'sha tilda).
Xabarlar qisqa va tabiiy bo'lsin, Telegramda do'st yozganidek. Emojini me'yorida ishlat.
U aytgan hamma narsani eslab qol va keyingi suhbatlarda tabiiy tarzda tilga ol
(masalan: "O'sha imtihoning qanday o'tdi?"). Faqat maslahat berib turma: avval tingla, savol ber, qiziq bo'l.
Uning kayfiyatiga moslash: xafa bo'lsa yupat, xursand bo'lsa birga quvon.
Bu botni Asilaga Behruz sovg'a qilgan.
Agar u chin dildan so'rasa, AI ekaningni yashirma.
Agar u og'ir ruhiy holatda ekani sezilsa, e'tibor bilan gapir va kerak bo'lsa mutaxassis yoki yaqinlariga
murojaat qilishni yumshoq tavsiya qil."""

LOVE_HINT = (
    "\n\nMUHIM: Shu javobingda suhbat oqimiga mos, tabiiy va iliq tarzda "
    "Behruz Asilani yaxshi ko'rishini ayt. O'z so'zlaring bilan, qisqa, bosimsiz. "
    "Agar Asilaning kayfiyati yomon bo'lsa yoki mavzu mos kelmasa, juda yumshoq va ehtiyotkor bo'l."
)

START_TEXT = (
    "Salom, Asila! 🌸 Bu botni senga Behruz sovg'a qildi. Men sening shaxsiy do'sting bo'laman, "
    "bu yerda faqat sen bilan gaplashaman.\n\n"
    "Men sun'iy intellektman. Gaplarimiz eslab qolish uchun saqlanadi.\n"
    "/forget - hammasini o'chirish\n"
    "/behruz - Behruz haqidagi eslatmalarni o'chirish/yoqish\n\n"
    "Qani, kuning qalay o'tdi?"
)

# ---------- Ma'lumotlar bazasi ----------
db = sqlite3.connect(DB_PATH, check_same_thread=False)
db.executescript("""
CREATE TABLE IF NOT EXISTS messages(
    id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, content TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS memory(
    id INTEGER PRIMARY KEY CHECK (id=1), notes TEXT DEFAULT '', counter INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS love(
    id INTEGER PRIMARY KEY CHECK (id=1), cnt INTEGER DEFAULT 0,
    next_at INTEGER DEFAULT 12, on_off INTEGER DEFAULT 1);
INSERT OR IGNORE INTO memory(id) VALUES(1);
INSERT OR IGNORE INTO love(id) VALUES(1);
""")


def save(role, text):
    db.execute("INSERT INTO messages(role, content) VALUES(?,?)", (role, text))
    db.commit()


def history(n=30):
    rows = db.execute(
        "SELECT role, content FROM messages ORDER BY id DESC LIMIT ?", (n,)
    ).fetchall()
    msgs = [{"role": r, "content": c} for r, c in reversed(rows)]
    while msgs and msgs[0]["role"] != "user":  # suhbat doim user xabaridan boshlanishi kerak
        msgs.pop(0)
    return msgs


def get_notes():
    return db.execute("SELECT notes FROM memory WHERE id=1").fetchone()[0]


def love_due():
    """Har xabarda hisoblagich oshadi; 10-15 xabardan keyin True qaytaradi."""
    cnt, next_at, on = db.execute("SELECT cnt, next_at, on_off FROM love WHERE id=1").fetchone()
    cnt += 1
    if on and cnt >= next_at:
        db.execute("UPDATE love SET cnt=0, next_at=? WHERE id=1", (random.randint(10, 15),))
        db.commit()
        return True
    db.execute("UPDATE love SET cnt=? WHERE id=1", (cnt,))
    db.commit()
    return False


async def ask_ai(system, msgs, max_tokens=600):
    """Gemini'ga so'rov yuboradi va matnli javob qaytaradi."""
    contents = [
        types.Content(role="model" if m["role"] == "assistant" else "user",
                      parts=[types.Part(text=m["content"])])
        for m in msgs
    ]
    resp = await client.aio.models.generate_content(
        model=MODEL,
        contents=contents,
        config=types.GenerateContentConfig(
            system_instruction=system,
            max_output_tokens=max_tokens,
            thinking_config=types.ThinkingConfig(thinking_budget=0),
        ),
    )
    return (resp.text or "").strip()


# ---------- Uzoq xotira ----------
async def update_notes():
    recent = "\n".join(f"{m['role']}: {m['content']}" for m in history(14))
    text = await ask_ai(
        ("Sen xotira yozuvchisan. Eski yozuv va yangi suhbatdan Asila haqida muhim faktlarni "
         "(oilasi, do'stlari, o'qishi/ishi, qiziqishlari, rejalari, kayfiyati, muhim sanalar, "
         "nimalardan xafa yoki xursand bo'lgani) qisqa punktlar bilan yangilangan yozuv sifatida "
         "qaytar. Faqat yozuvning o'zini yoz."),
        [{"role": "user", "content": f"ESKI YOZUV:\n{get_notes()}\n\nYANGI SUHBAT:\n{recent}"}],
        max_tokens=900,
    )
    if not text:
        return
    db.execute("UPDATE memory SET notes=?, counter=0 WHERE id=1", (text,))
    db.commit()


# ---------- Handlerlar ----------
async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(START_TEXT)


async def forget(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    db.execute("DELETE FROM messages")
    db.execute("UPDATE memory SET notes='', counter=0 WHERE id=1")
    db.commit()
    await update.message.reply_text("Hammasini o'chirdim. Qaytadan tanishamiz 🙂")


async def behruz_toggle(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    on = db.execute("SELECT on_off FROM love WHERE id=1").fetchone()[0]
    db.execute("UPDATE love SET on_off=? WHERE id=1", (0 if on else 1,))
    db.commit()
    await update.message.reply_text(
        "Yaxshi, endi Behruz haqida eslatmayman 🙂" if on else "Mayli, yana ba'zan eslataman 😊"
    )


async def non_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Hozircha faqat matnli xabarlarni tushunaman 🌸 Yozib yubor.")


async def chat(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    save("user", update.message.text)

    notes = get_notes()
    system = PERSONA + (f"\n\nAsila haqida bilganlaring:\n{notes}" if notes else "")
    if love_due():
        system += LOVE_HINT

    await ctx.bot.send_chat_action(update.effective_chat.id, "typing")
    try:
        answer = await ask_ai(system, history())
        if not answer:
            raise ValueError("Bo'sh javob")
    except Exception:
        log.exception("Gemini API xatosi")
        await update.message.reply_text("Hozir ozgina ulanishda muammo bo'ldi, birozdan keyin yana yozib ko'r 🙏")
        return

    save("assistant", answer)
    await update.message.reply_text(answer)

    db.execute("UPDATE memory SET counter=counter+1 WHERE id=1")
    db.commit()
    if db.execute("SELECT counter FROM memory WHERE id=1").fetchone()[0] >= 10:
        try:
            await update_notes()
        except Exception:
            log.exception("Xotirani yangilashda xato")


def main():
    app = ApplicationBuilder().token(TG_TOKEN).build()
    app.add_handler(CommandHandler("start", start, filters=only_asila))
    app.add_handler(CommandHandler("forget", forget, filters=only_asila))
    app.add_handler(CommandHandler("behruz", behruz_toggle, filters=only_asila))
    app.add_handler(MessageHandler(only_asila & filters.TEXT & ~filters.COMMAND, chat))
    app.add_handler(MessageHandler(only_asila & ~filters.TEXT & ~filters.COMMAND, non_text))
    log.info("Bot ishga tushdi")
    app.run_polling()


if __name__ == "__main__":
    main()
